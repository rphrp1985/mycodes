#include <iostream>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <queue>
#include <set>
#include<bits/stdc++.h>
using namespace std;

struct Assignment {
    vector<int> inputs;
    int output;
    string food;
};

void parseInput(unordered_map<int, Assignment>& assignments, unordered_map<string, int>& foodCosts,
                vector<int>& startState, vector<int>& goalState, int &grpsize) {
    // Food costs
    foodCosts["TC"] = 1;
    foodCosts["DF"] = 1;
    foodCosts["PM"] = 1;
    foodCosts["GJ"] = 1;

    grpsize=2;
    // Start state
    startState = {1, 2, 3, 4, 5, 6};

    // Goal state
    goalState = {13, 14, 17};

    // Assignment dependencies
    assignments[1] = {{1, 3}, 7, "TC"};
    assignments[2] = {{4, 2}, 8, "TC"};
    assignments[3] = {{1, 3}, 9, "TC"};
    assignments[4] = {{2, 3}, 10, "PM"};
    assignments[5] = {{7, 8}, 11, "TC"};
    assignments[6] = {{4, 6}, 12, "TC"};
    assignments[7] = {{6, 9}, 13, "PM"};
    assignments[8] = {{10, 5}, 14, "GJ"};
    assignments[9] = {{1, 11}, 15, "DF"};
    assignments[10] = {{3, 12}, 16, "TC"};
    assignments[11] = {{15, 16}, 17, "DF"};
}

  
    map<int,map<int, vector< vector<int>  >  > > lvlorder;  // stores path means at level x contains whole path from of output from level 0
// map< level, map< output, vectors containing path < 


 unordered_map<int, Assignment> assignments;
    unordered_map<string, int> foodCosts;
    vector<int> startState;
    vector<int> goalState;
    int grpsize;
    
int maxgoal=0;




void printpath( vector< vector< pair<int,string>>> path ){
  
  for(int i =0;i< path.size();i++){
    cout<<"Day "<<i+1<<" : ";
    for(auto it:path[i]){
      cout<<" assignment "<<it.first<<" ";
    }
    cout<<"\n";
  }
  
  
  cout<<"\n\n\n";
  
  
}


#include <fstream>
#include <string>
#include <utility> // for std::pair


int totalres=0;
void printpathToFile(const vector<vector<pair<int, string>>>& path ) {
    string filename= "out.txt";
   fstream outputFile(filename, ios::app); // Open in append mode


   map<string , int> tmpmp;

   for(int i=0;i<path.size();i++){
    map<string,int> tmpmp2;
    for(int j =0;j<path[i].size() ; j++  ){
            tmpmp2[path[i][j].second]++;
    }  

    //  for (map<int, string>::iterator it = tmpmp2.begin(); it != tmpmp2.end(); ++it) {
    //     cout << "Key: " << it->first << ", Value: " << it->second << endl;
    // }
      
    for(auto it: tmpmp2){
        auto s = it.first;
        int num = it.second;
        tmpmp[s]= max(tmpmp[s], num);
    }

    tmpmp2.clear();

   }

    if (!outputFile) {
        cerr << "Error: Unable to open file \"" << filename << "\" for writing." << endl;
        return;
    }

    for (int i = 0; i < path.size(); i++) {
        outputFile << "Day " << i + 1 << " : ";
        for (const auto& it : path[i]) {
            outputFile << " assignment " << it.first << " ";
        }
        outputFile << "\n";
    }

outputFile << "Menu : < ";
     for (auto it:tmpmp) {
        outputFile << it.second << " - "<<it.first<<" ";
       
       
    }
    tmpmp.clear();
    outputFile<<" > ";

     outputFile << "\n";



    outputFile << "\n\n\n";
    outputFile.close();

    cout << "Path successfully printed to file: " << filename << endl;
}




    
void dfs(vector<int> completedAss, vector<int> books, vector< vector< pair<int,string>>> path ){
  

//   for(auto it:books){
//     cout<<it<<" ";
//   }
//   cout<<endl;
  
//   printpathToFile(path);
  
  
  // if(path.size()>4)
  // return;
  
  int found=1;
    for(auto it : goalState){
      int foundtmp=0;
      for(auto it2: books)
      {
        if(it2==it){
          foundtmp=1;
        }
      }
      if(foundtmp==0){
        found=0;
      }
       
    }
     
     
    if(found){
        totalres++;;
      printpathToFile(path);
      
    //   exit(0);
       
      return;
    }
     
     
  
  
    vector<pair<int, pair<int,string>> > canbeexcec;
    // ass id ,  output, food
    
      for(int i=1;i<=assignments.size();i++){
        
        if( completedAss[i]==0 ){
          
          int vald=1;
          
          for(auto it : assignments[i].inputs){
            int val2=0;
            
            for(auto it1: books){
              if(it1==it) val2=1;
            }
            if(val2==0){
              vald=0;
            }
            
          }
          
          
          if(vald==1)
          canbeexcec.push_back({i,{assignments[i].output,assignments[i].food }});
          
        }
        
        
        
      }
      

      if(canbeexcec.size()==0)
      return;
      
      ///
      
       int n = canbeexcec.size();
       int r = grpsize;
    std::vector<bool> mask(r, true); // r true values for selecting combinations
    mask.resize(n, false);          // Rest are false

    do {
      
      
      vector<int> completedAss2= completedAss; 
      vector<int> books2= books;
      vector< vector< pair<int,string> > > path2 =path ;
      
     
      
      
        std::vector<pair<int, pair<int,string>>> combination;
        for (int i = 0; i < n; ++i) {
            if (mask[i]) {
                combination.push_back(canbeexcec[i]);
            }
        }
        
        
        
        vector<pair<int, string>> tmp;
        int nodfs=0;
        for(auto it: combination){
          // it.first = ass id
          int outff= assignments[it.first].output;

          if(outff>maxgoal)
            nodfs=1;
            
          tmp.push_back({ it.first, assignments[it.first].food   });
          books2.push_back(outff);
          completedAss2[it.first]=1;
          
          
      
        }

        path2.push_back(tmp);
        tmp.clear();

        if(nodfs==0)
        dfs(completedAss2,books2, path2);

        completedAss2.clear();
        books2.clear();
        path2.clear();
        // cout<<"\n";
       
    } while (std::prev_permutation(mask.begin(), mask.end()));
      
     
  
  
}



int main() {
   
   
   
    

    parseInput(assignments, foodCosts, startState, goalState, grpsize);

    for(auto it:goalState){
        maxgoal = max(maxgoal,it);
    }
    
    int n_ass= assignments.size();
    vector<int> completedAss(n_ass+2,0);
    
    vector< vector< pair<int,string>>> path;
    dfs(completedAss, startState, path);

    cout<<"total Found"<<totalres;
    
    // queue<> q;
    
    // q.push({0,{},  })  // level, already solved, 
    
    
    // cout<<grpsize;
    
    

  

    return 0;
}
