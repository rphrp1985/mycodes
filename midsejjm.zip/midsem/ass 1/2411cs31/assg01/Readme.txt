

## Input Format

The program reads input from a file named `in.txt`. Below is the format you should follow for providing input:

1. **Food Costs**: Use the format:
   ```
   C <foodName> <cost>
   ```
   Example:
   ```
   C Pizza 10
   ```

2. **Group Size**: Specify the size of the group with:
   ```
   G <groupSize>
   ```
   Example:
   ```
   G 3
   ```

3. **Start State (Books)**: List the initial state of books with:
   ```
   I <book1> <book2> ... -1
   ```
   Example:
   ```
   I 1 2 3 -1
   ```

4. **Goal State**: Define the target state with:
   ```
   O <goal1> <goal2> ... -1
   ```
   Example:
   ```
   O 4 5 -1
   ```

5. **Assignments**: Define the assignments using the following format:
   ```
   A <assignmentID> <input1> <input2> <output> <foodName>
   ```
   Example:
   ```
   A 1 1 2 4 Pizza
   A 2 3 4 5 Burger
   ```

**Note**: Lines starting with `%` are treated as comments and will be ignored by the program. Empty lines are also ignored.

## Output

The results of the scheduling will be written to a file named `schedules.txt`. The output includes:

- A list of valid schedules, each day specifying which assignments were performed.
- A summary of the food menu indicating how many times each food item was served.

**Output Example**:
```
Day 1 : assignment 1 
Day 2 : assignment 2 
Food Menu : [ 1 - Pizza , 1 - Burger , ]
```

## How to Run the Program

1. Ensure you have a C++ compiler installed (e.g., g++, clang).
2. Place the `in.txt` file in the same directory as your program.
3. Compile the program:
   ```
   g++ your_program.cpp -o schedule
   ```
4. Run the program:
   ```
   ./schedule
   ```

5. Check the `schedules.txt` file for the output.

