#include <iostream>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <queue>
#include <set>
#include<bits/stdc++.h>
using namespace std;

struct Assignment {
    vector<int> inputs;
    int output;
    string food;
};




  

 unordered_map<int, Assignment> assignments;
    unordered_map<string, int> foodCosts;
    vector<int> startState;
    vector<int> goalState;
    int grpsize;
    
int maxgoal=0;





#include <fstream>
#include <string>
#include <utility> 


int totalres=0;

void printpathToFile(const vector<vector<pair<int, string>>>& path ) ;



// dfs function    
void dfs(vector<int> completedAss, vector<int> books, vector< vector< pair<int,string>>> path ){
  
  
  int found=1;
  for(auto it : goalState){  // finding if all already got the goal state .
      int foundtmp=0;
      for(auto it2: books)
      {
        if(it2==it){
          foundtmp=1;
        }
      }
      if(foundtmp==0){
        found=0;
      }
       
    }
     
     
    if(found){ // goal state is found.
        totalres++;;
    printpathToFile(path); // printing to file out.txt
      
    //   exit(0);
       
     return;
    }
     
     
  
  
    vector<pair<int, pair<int,string>> > canbeexcec;
    // vector<assignment_id , pair< output, food>>
    
    //  finding from here  all valid assignments that can be executed and yet not executed.
      for(int i=1;i<=assignments.size();i++){
        
        if( completedAss[i]==0 ){
          
          int vald=1;
          
          for(auto it : assignments[i].inputs){
            int val2=0;
            
            for(auto it1: books){
              if(it1==it) val2=1;
            }
            if(val2==0){
              vald=0;
            }
            
          }
          
          
          if(vald==1)
          canbeexcec.push_back({i,{assignments[i].output,assignments[i].food }});   // found one assigmnet that satisfies f=given criteria  
          
        }
        
        
        
      }
      

      if(canbeexcec.size()==0)
      return;  // non found then return;
      
      
      ///
      
       int n = canbeexcec.size();
       
       
       
       // now findng nCr to get all combination of assigments from CanbeExecuted.
       for(int i=grpsize;i<=grpsize;i++){
       
       int r = i;
    std::vector<bool> mask(r, true); // r true values for selecting combinations
    mask.resize(n, false);          // Rest are false

    do {
      
      
      // copying varibales to pass through dfs
      vector<int> completedAss2= completedAss; 
      vector<int> books2= books;
      vector< vector< pair<int,string> > > path2 =path ;
      
     
      
        // 
        std::vector<pair<int, pair<int,string>>> combination;
        for (int i = 0; i < n; ++i) {
            if (mask[i]) {
                combination.push_back(canbeexcec[i]);
            }
        }
        
        
        
        vector<pair<int, string>> tmp;
        int nodfs=0;
        for(auto it: combination){
          // it.first = ass id
          int outff= assignments[it.first].output;

          //if(outff>maxgoal)
           // nodfs=1;
            
          tmp.push_back({ it.first, assignments[it.first].food   });
          books2.push_back(outff);
          completedAss2[it.first]=1;
          
          
      
        }

        path2.push_back(tmp);
        tmp.clear();  // clearing space

      //  if(nodfs==0)
        dfs(completedAss2,books2, path2); // calling dfs again . 

	// clearing data to save memory
        completedAss2.clear();
        books2.clear();
        path2.clear();
        // cout<<"\n";
       
    } while (std::prev_permutation(mask.begin(), mask.end()));  // getting combinations.
      
     }
  
  
}







// getting input from file.
void get_input_from_file(unordered_map<int, Assignment>& assignments, unordered_map<string, int>& foodCosts,
                vector<int>& startState, vector<int>& goalState, int &grpsize ) {


    string filename="in.txt"  ;  
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Error opening file!" << endl;
        return;
    }

    string line;
    while (getline(file, line)) {
        if (line.empty() || line[0] == '%') { // ignoring comments or empty line in input
            
            continue;
        }

        stringstream ss(line);
        string command;
        ss >> command;

        if (command == "C") {   // for food
            string foodName;
            int cost;
            ss >> foodName >> cost;
            foodCosts[foodName] = cost;
        } else if (command == "G") {  // group size
            ss >> grpsize;
        } else if (command == "I") {  //books    (start state)
            int book;
            while (ss >> book && book != -1) {
                startState.push_back(book);
            }
        } else if (command == "O") {  // output // GoalState
            int outcome;
            while (ss >> outcome && outcome != -1) {  // 
                goalState.push_back(outcome);
            }
        } else if (command == "A") {    // dependecy list for assignments
            int id, input1, input2, output;
            string foodName;
            ss >> id >> input1 >> input2 >> output >> foodName;
            assignments[id] = {{input1, input2}, output, foodName};
        }
    }

    file.close();
}



void printpathToFile(const vector<vector<pair<int, string>>>& path ) {
    string filename= "schedules.txt";
   fstream outputFile(filename, ios::app); // Open in append mode to append output  in file for each valid output.



    if (!outputFile) {
        cerr << "Error: Unable to open file \"" << filename << "\" for writing." << endl;
        return;
    }

    for (int i = 0; i < path.size(); i++) {
        outputFile << "Day " << i + 1 << " : ";
        for (const auto& it : path[i]) {
            outputFile << " assignment " << it.first << " ";
        }
        outputFile << "\n";
    }
    
    
   map<string , int> tmpmp; // for finding Menu



   for(int i=0;i<path.size();i++){
    map<string,int> tmpmp2;
    for(int j =0;j<path[i].size() ; j++  ){
            tmpmp2[path[i][j].second]++;
    }  

    //  for (map<int, string>::iterator it = tmpmp2.begin(); it != tmpmp2.end(); ++it) {
    //     cout << "Key: " << it->first << ", Value: " << it->second << endl;
    // }
      
    for(auto it: tmpmp2){
        auto s = it.first;
        int num = it.second;
        tmpmp[s]= max(tmpmp[s], num);
    }

    tmpmp2.clear(); // clearing memory

   }

     outputFile << "Food Menu : [ ";
     for (auto it:tmpmp) {
        outputFile << it.second << " - "<<it.first<<" , ";
       
       
    }
    tmpmp.clear();
    outputFile<<" ] ";

     outputFile << "\n";



    outputFile << "\n\n\n";
    outputFile.close();

    cout << "Schedule Number "<<totalres<<" printed to file " << filename << endl;
}









int main() {
   
  
    // getting input from in.txt file
    get_input_from_file(assignments, foodCosts, startState, goalState, grpsize);

	
    // getting max-goal for opting cases excedding max goal
    for(auto it:goalState){
        maxgoal = max(maxgoal,it);
    }
    
    int ass_size= assignments.size();  // getting assignmtes number;
    vector<int> completedAss(ass_size+2,0);
    
    vector< vector< pair<int,string>>> path; //     dummy variable to pass through dfs code. 
    dfs(completedAss, startState, path);  // calling dfs funtion fot recursivly find soution.

    cout<<"Total Schedule Found :  "<<totalres;
    
   

  

    return 0;
}
