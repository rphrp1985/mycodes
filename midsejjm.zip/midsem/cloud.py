import requests

url = "https://api3.prlabsapi.com/gpt4"
url = "https://api3.prlabsapi.com/o3mini"

url = "https://api3.prlabsapi.com/deepseekai"

# conversationllama3
# gpt4
# claude3


payload = {
	"messages": [
		{
			"role": "user",
			"content": "hi"
		}
	],
	"web_access": False
}
headers = {
	"X-RapidAPI-Proxy-Secret": "jhfh5jghrijrnttjjmyukynfit",
	
}

response = requests.post(url, json=payload, headers=headers)

print(response.json())