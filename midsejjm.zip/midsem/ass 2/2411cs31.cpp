// $./a.exe testcases/input01.dag  use this to run the program

#include <iostream>
#include <fstream>
#include <bits/stdc++.h>
#include <string>
#include <utility>

using namespace std;

string inputFileName;
string outputFileName;
//Assignment class for storing assignment information;
class Assignment {
public:
    vector<int> inputRequirements; // Requirements to complete the assignment
    int outputAssignment;               // Output after completing the assignment
    string foodLabel;                    // food required to complete the assignment    

};


void get_input(map<int, Assignment>& taskMap, map<string, int>& foodPricing,
               vector<int>& initialState, vector<int>& finalState, int& groupSize) {

    string filename = inputFileName;
    ifstream inputFile(filename);
    if (!inputFile.is_open()) {
        cerr << "Error opening file!" << endl;
        return;
    }

    string line;
    while (getline(inputFile, line)) {
        if (line.empty() || line[0] == '%') {
            continue;
        }

        stringstream ss(line);
        string command;
        ss >> command;

        
        int commandType = -1;
        if (command == "C") commandType = 0;
        else if (command == "G") commandType = 1;
        else if (command == "I") commandType = 2;
        else if (command == "O") commandType = 3;
        else if (command == "A") commandType = 4;

        switch (commandType) {
            case 0: { // "C" for food pricing
                string foodLabel;
                int cost;
                ss >> foodLabel >> cost;
                foodPricing[foodLabel] = cost;
                break;
            }
            case 1: { // "G" for group size
                ss >> groupSize;
                break;
            }
            case 2: { // "I" for initial state
                int book;
                while (ss >> book && book != -1) {
                    initialState.push_back(book);
                }
                break;
            }
            case 3: { // "O" for final state
                int outcome;
                while (ss >> outcome && outcome != -1) {
                    finalState.push_back(outcome);
                }
                break;
            }
            case 4: { // "A" for task map
                int id, input1, input2, output;
                string foodLabel;
                ss >> id >> input1 >> input2 >> output >> foodLabel;
                taskMap[id] = {{input1, input2}, output, foodLabel};
                break;
            }
            default:
                cerr << "Unknown command: " << command << endl;
                break;
        }
    }

    inputFile.close();
}


struct SubState {
    vector<int> completedTasks;  // Stores IDs of completed tasks
    vector<int> booksCollection; // Stores collected books
    vector<vector<pair<int, string>>> taskRoutes; // Stores tassignment completion path
};

bool checkGoalAchieved(
    vector<int>& finalState,
    vector<int> booksCollection) {

    int goalAchieved = 1; // Assume goal is achieved initially

for (int i = 0; i < finalState.size(); i++) {
    int goalItem = finalState[i];
    int itemFound = 0; // Assume goal item is not found
    
    for (int j = 0; j < booksCollection.size(); j++) {
        int book = booksCollection[j];
        if (book == goalItem) {
            itemFound = 1; // Goal item is found
        }
    }
    
    if (itemFound == 0) {
        goalAchieved = 0; // Goal item not found
    }
}

return goalAchieved;
}

//writing to file
void writePathToFile(const vector<vector<vector<pair<int, string>>>>& allsol) {

    string filename = outputFileName;
    fstream outputFile(filename, ios::out);
    for(auto taskPath:allsol){
  

    if (!outputFile) {
        cerr << "Error: Unable to open file \"" << filename << "\" for writing." << endl;
        return;
    }

    for (int i = 0; i < taskPath.size(); i++) {
        outputFile << "Day " << i + 1 << " : ";
        for (const auto& task : taskPath[i]) {
            outputFile << " assignment " << task.first << " ";
        }
        outputFile << "\n";
    }

    map<string, int> menuTracker;

    for (int i = 0; i < taskPath.size(); i++) {
        map<string, int> dailyMenu;
        for (int j = 0; j < taskPath[i].size(); j++) {
            dailyMenu[taskPath[i][j].second]++;
        }

        for (auto menu : dailyMenu) {
            auto foodLabel = menu.first;
            int count = menu.second;
            menuTracker[foodLabel] = max(menuTracker[foodLabel], count);
        }

        dailyMenu.clear();
    }

    outputFile << "Food Menu : [ ";
    for (auto menu : menuTracker) {
        outputFile << menu.second << " - " << menu.first << " , ";
    }
    menuTracker.clear();
    outputFile << " ] ";

    outputFile << "\n\n\n";
   

    // cout << "Schedule Number " << totalSchedulesCount << " printed to file " << filename << endl;
}
 outputFile.close();
}


vector<pair<int, pair<int, string>>> getExecutableAssignments(
    map<int, Assignment>& taskMap,
    vector<int> completedTasks,
    vector<int> booksCollection) {

   vector<pair<int, pair<int, string>>> executableTasks;

for (int i = 1; i <= taskMap.size(); i++) {
    // Check if the task is not completed
    if (completedTasks[i] == 0) {
        int isValid = 1; // Assume the task is valid initially

        // Check input requirements for the task
        for (int j = 0; j < taskMap[i].inputRequirements.size(); j++) {
            int requirement = taskMap[i].inputRequirements[j];
            int isAvailable = 0; // Assume the requirement is not available

            // Search for the requirement in the booksCollection
            for (int k = 0; k < booksCollection.size(); k++) {
                int book = booksCollection[k];
                if (book == requirement) {
                    isAvailable = 1; // Requirement found
                }
            }

            // If the requirement is not available, the task is invalid
            if (isAvailable == 0) {
                isValid = 0;
            }
        }

        // If the task is valid, add it to the executableTasks
        if (isValid == 1) {
            int taskOutput = taskMap[i].outputAssignment;
            string taskLabel = taskMap[i].foodLabel;
            executableTasks.push_back({i, {taskOutput, taskLabel}});
        }
    }
}

    return executableTasks;
}
vector<SubState> makeCombinationsOfAssignmentsSelections(
    map<int, Assignment>& taskMap,
    map<string, int>& foodPricing,
    vector<int>& initialState,
    vector<int>& finalState,
    int& groupSize,
    vector<int> completedTasks,
    vector<int> booksCollection,
    vector<vector<pair<int, string>>> taskRoutes,
    vector<bool> mask,
    vector<pair<int, pair<int, string>>> executableTasks) {

    int taskCount = executableTasks.size();

    vector<SubState> v;

    do {
    // Temporary variables to hold current states
    vector<int> tempCompletedTasks = completedTasks; // Copying the completed tasks
    vector<int> tempBooksCollection = booksCollection; // Copying the books collection
    vector<vector<pair<int, string>>> tempTaskRoutes = taskRoutes; // Copying the task routes

    // Create a combination vector to store selected tasks
    vector<pair<int, pair<int, string>>> combination;
    for (int i = 0; i < taskCount; ++i) {
        if (mask[i]) { // Check if the mask allows this task
            combination.push_back(executableTasks[i]); // Add task to combination
        }
    }

    // A temporary path vector to store the current route
    vector<pair<int, string>> tempPath;
    for (auto task : combination) {
        // Get the output assignment of the current task
        int taskOutput = taskMap[task.first].outputAssignment;

        // Add the task's first element and its food label to the path
        tempPath.push_back({task.first, taskMap[task.first].foodLabel});
        tempBooksCollection.push_back(taskOutput); // Add the output to books collection
        tempCompletedTasks[task.first] = 1; // Mark the task as completed
    }

    // Push the path into the task routes
    tempTaskRoutes.push_back(tempPath);

    // Create a substate to store the modified data
    struct SubState substate = {
        tempCompletedTasks, // Update the completed tasks
        tempBooksCollection, // Update the books collection
        tempTaskRoutes // Update the task routes
    };

    // Add the current substate to the vector
    v.push_back(substate);

    // free up memory
    tempCompletedTasks.clear();
    tempBooksCollection.clear();
    tempTaskRoutes.clear();
    tempPath.clear(); // Emptying the path for the next iteration

    
    int n = mask.size();
    int k = n - 1;

    
    while (k > 0 && mask[k - 1] <= mask[k]) {
        --k;
    }

    if (k > 0) {
        int l = n - 1;

        // Find the largest element to the right of `k - 1` that is smaller than mask[k - 1]
        while (mask[l] >= mask[k - 1]) {
            --l;
        }

        // Swap the two elements
        swap(mask[k - 1], mask[l]);
    }

    // Reverse the sequence from `k` to the end of the array
    reverse(mask.begin() + k, mask.end());

} while (!is_sorted(mask.begin(), mask.end(), greater<int>())); // Continue until the mask is sorted in descending order

    return v;
}

vector<vector<pair<int, string>>> question1_Sol;
int q1_minday= INT_MAX;
void solve_question1(vector<vector<pair<int, string>>> &taskRoutes){ // solving question1 

    int n = taskRoutes.size();
    if(q1_minday>n){
        q1_minday= n;
        question1_Sol = taskRoutes;
    }

}

vector<vector<pair<int, string>>> question2_Sol;
int q2_mincost= INT_MAX;
 // solving question 2
void solve_question2(vector<vector<pair<int, string>>> &taskPath, map<string,int> &foodPricing){

    
    map<string, int> menuTracker;

    for (int i = 0; i < taskPath.size(); i++) {
        map<string, int> dailyMenu;
        for (int j = 0; j < taskPath[i].size(); j++) {
            dailyMenu[taskPath[i][j].second]++;
        }

        for (auto menu : dailyMenu) {
            auto foodLabel = menu.first;
            int count = menu.second;
            menuTracker[foodLabel] = max(menuTracker[foodLabel], count);
        }

        dailyMenu.clear();
    }

   int currcost=0;
    for (auto menu : menuTracker) {
         currcost+= menu.second *  foodPricing[menu.first] ;
    }
    menuTracker.clear();

    if(currcost<q2_mincost){
        q2_mincost= currcost;
        question2_Sol = taskPath;
    }


}

vector<vector<pair<int, string>>> question3_Sol;
int q3_minday= INT_MAX;
 // solving question 3
void solve_question3(vector<vector<pair<int, string>>> &taskPath,map<string, int> givenMenu ){

    map<string, int> menuTracker;

    for (int i = 0; i < taskPath.size(); i++) {
        map<string, int> dailyMenu;
        for (int j = 0; j < taskPath[i].size(); j++) {
            dailyMenu[taskPath[i][j].second]++;
        }

        for (auto menu : dailyMenu) {
            auto foodLabel = menu.first;
            int count = menu.second;
            menuTracker[foodLabel] = max(menuTracker[foodLabel], count);
        }

        dailyMenu.clear();
    }

    if(givenMenu!=menuTracker){
        return;
    }

    int n = taskPath.size();
    if(q3_minday>n){
        q3_minday= n;
        question3_Sol = taskPath;
    }

}


vector<vector<pair<int, string>>> question4_Sol;
int q4_mincost= INT_MAX;
 // solving question 4
void solve_question4(vector<vector<pair<int, string>>> &taskPath, map<string,int> &foodPricing, int k){

    if(k<taskPath.size())
    return;
    map<string, int> menuTracker;

    for (int i = 0; i < taskPath.size(); i++) {
        map<string, int> dailyMenu;
        for (int j = 0; j < taskPath[i].size(); j++) {
            dailyMenu[taskPath[i][j].second]++;
        }

        for (auto menu : dailyMenu) {
            auto foodLabel = menu.first;
            int count = menu.second;
            menuTracker[foodLabel] = max(menuTracker[foodLabel], count);
        }

        dailyMenu.clear();
    }

   int currcost=0;
    for (auto menu : menuTracker) {
         currcost+= menu.second *  foodPricing[menu.first] ;
    }
    menuTracker.clear();

    if(currcost<q4_mincost){
        q4_mincost= currcost;
        question4_Sol = taskPath;
    }


}





//printinh the schedule to console
void PrintSchedule(const vector<vector<pair<int, string>>>& taskPath) {
    
    for (int i = 0; i < taskPath.size(); i++) {
        cout<< "Day " << i + 1 << " : ";
        for (const auto& task : taskPath[i]) {
         cout << " assignment " << task.first << " ";
        }
        cout << "\n";
    }

    // cout << "Schedule Number " << totalSchedulesCount << " printed to file " << filename << endl;
}






int main(int argc, char* argv[]) {

       if (argc < 2) {
        cerr << "Usage: " << argv[0] << " <input_file>" << endl;
        return 1;
    }

    inputFileName = argv[1];
    // inputFileName= "testcases/input01.dag";
    outputFileName="out.dag";
    cout<<"Opening File "<<inputFileName<<endl;
    map<string, int> foodPricing;
    vector<int> initialState;
    map<int, Assignment> taskMap;
    vector<int> finalState;

    int groupSize;

    // getting input from file
    get_input(taskMap, foodPricing, initialState, finalState, groupSize);

    int taskSize = taskMap.size();
    vector<int> completedTasks1(taskSize + 1, 0);

    vector<vector<pair<int, string>>> taskRoutes1;

    // taking inputs from user.
    int k ;
    cout<<"Enter the value of k\n";
    cin>>k;

    map<string,int> givenMenu;
    cout<<"enter the menu for question 4. To finish entering the menu enter -1.\nFormat dish-name count\n";


    while(true){
        string x;
        int y;
        cin>>x;
        if(x=="-1"){
            break;
        }
        cin>>y;
        givenMenu[x]=y;
    }

    // applying BFS
    queue< SubState> q;

     struct SubState task = {
    completedTasks1,                        
    initialState,                          
    taskRoutes1            
};

    q.push(task);
    

    vector<vector<vector<pair<int, string>>>> allSolutions ;
    int count=0;
    while(!q.empty()){

        auto it = q.front();
        q.pop();
      
        auto booksCollection= it.booksCollection;
         vector<int> completedTasks = it.completedTasks;
        vector<vector<pair<int, string>>> taskRoutes= it.taskRoutes;

        if (checkGoalAchieved(finalState, booksCollection)) { // this path reaches goal state.
            allSolutions.push_back(taskRoutes);
        
        count++;
        // solving questions.
        solve_question1(taskRoutes);
        solve_question2(taskRoutes, foodPricing);
        solve_question3(taskRoutes, givenMenu);
        solve_question4(taskRoutes, foodPricing, k);
       
        continue;
        
    }

    auto executableTasks = getExecutableAssignments(taskMap, completedTasks, booksCollection);


    if (executableTasks.size() == 0) continue;;
    
        int taskCount = executableTasks.size();
        vector<bool> mask(groupSize, true);
        mask.resize(taskCount, false);

        // getting combinations of executable tasks.
        auto combinations= makeCombinationsOfAssignmentsSelections(taskMap,
                                                foodPricing,
                                                initialState,
                                                finalState,
                                                groupSize,
                                                completedTasks,
                                                booksCollection,
                                                taskRoutes,
                                                mask,
                                                executableTasks);

        for(auto it:combinations){  // adding next state to queue/
            q.push(it);
        }

    }
  
    // cout<<count<<endl;

//  printing required solutiions/
    cout<<"###############    The Solution For Question 1 is  ##################### \n";
    PrintSchedule(question1_Sol);

    
    cout<<"\n\n###############    The Solution For Question 2 is  ##################### \n";
    cout<<"food cost is "<<q2_mincost<<endl;
    PrintSchedule(question2_Sol);

    cout<<"\n\n###############    The Solution For Question 3 is  ##################### \n";
    if(question3_Sol.size()==0)
    cout<<"Solution does not exist\n";
    PrintSchedule(question3_Sol);

    cout<<"\n\n###############    The Solution For Question 4 is  ##################### \n";
    
    if(q4_mincost==INT_MAX){
        cout<<"Solution does not exist\n";
    }else{
        cout<<"Minimum food cost is "<<q4_mincost<<endl;;
    PrintSchedule(question4_Sol);
    }

    writePathToFile(allSolutions);

   
    return 0;
}

