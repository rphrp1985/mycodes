#include <iostream>
#include <fstream>
#include <string>
#include <utility>
#include <bits/stdc++.h>
using namespace std;

// Structure to represent each Assignment
struct Assignment {
    vector<int> inputRequirements; // Requirements to complete the assignment
    int outputAssignment;          // Output after completing the assignment
    string foodLabel;              // Label for the food item associated
};

// File names for input and output
string outputFileName = "out.txt";
string inputFileName = "testcases/input01.dag";

// Global variable to count total schedules
int totalSchedulesCount = 0;

// Function to write task paths to the output file
void writePathToFile(const vector<vector<pair<int, string>>>& taskPath);
void findCost(const vector<vector<pair<int, string>>>& taskPath,  map<string, int>& foodPricing) ;

// Function to check if the goal is achieved
bool checkGoalAchieved(
    vector<int>& finalState,
    vector<int> booksCollection) {

    int goalAchieved = 1; // Assume goal is achieved initially
    for (auto goalItem : finalState) {
        int itemFound = 0;
        for (auto book : booksCollection) {
            if (book == goalItem) {
                itemFound = 1; // Goal item is found
            }
        }
        if (itemFound == 0) {
            goalAchieved = 0; // Goal item not found
        }
    }

    return goalAchieved;
}

// Function to increment total schedule count
void increaseCount() {
    totalSchedulesCount++;
}



// Function to get executable assignments based on current state
vector<pair<int, pair<int, string>>> getExecutableAssignments(
    map<int, Assignment>& taskMap,
    vector<int> completedTasks,
    vector<int> booksCollection) {

    vector<pair<int, pair<int, string>>> executableTasks;

    for (int i = 1; i <= taskMap.size(); i++) {
        if (completedTasks[i] == 0) { // Check if task is not completed
            int isValid = 1;

            for (auto requirement : taskMap[i].inputRequirements) {
                int isAvailable = 0;

                for (auto book : booksCollection) {
                    if (book == requirement) isAvailable = 1; // Requirement found
                }
                if (isAvailable == 0) {
                    isValid = 0; // Requirement not met
                }
            }

            if (isValid == 1)
                executableTasks.push_back({i, {taskMap[i].outputAssignment, taskMap[i].foodLabel}});
        }
    }

    return executableTasks;
}

int minDays=INT_MAX;
vector<vector<pair<int, string>>> assignmtsRoute;



// Recursive function to search for task combinations
void recursiveSearch(
    map<int, Assignment>& taskMap,
    map<string, int>& foodPricing,
    vector<int>& initialState,
    vector<int>& finalState,
    int& groupSize,
    vector<int> completedTasks,
    vector<int> booksCollection,
    vector<vector<pair<int, string>>> taskRoutes);

// Function to make all possible combinations of assignment selections
void makeCombinationsOfAssignmentsSelections(
    map<int, Assignment>& taskMap,
    map<string, int>& foodPricing,
    vector<int>& initialState,
    vector<int>& finalState,
    int& groupSize,
    vector<int> completedTasks,
    vector<int> booksCollection,
    vector<vector<pair<int, string>>> taskRoutes,
    vector<bool> mask,
    vector<pair<int, pair<int, string>>> executableTasks) {

    int taskCount = executableTasks.size();

    do {
        vector<int> tempCompletedTasks = completedTasks;
        vector<int> tempBooksCollection = booksCollection;
        vector<vector<pair<int, string>>> tempTaskRoutes = taskRoutes;

        vector<pair<int, pair<int, string>>> combination;
        for (int i = 0; i < taskCount; ++i) {
            if (mask[i]) {
                combination.push_back(executableTasks[i]);
            }
        }

        vector<pair<int, string>> tempPath;
        for (auto task : combination) {
            int taskOutput = taskMap[task.first].outputAssignment;

            tempPath.push_back({task.first, taskMap[task.first].foodLabel});
            tempBooksCollection.push_back(taskOutput);
            tempCompletedTasks[task.first] = 1;
        }

        tempTaskRoutes.push_back(tempPath);

        recursiveSearch(
            taskMap,
            foodPricing,
            initialState,
            finalState,
            groupSize,
            tempCompletedTasks, tempBooksCollection, tempTaskRoutes);

        tempCompletedTasks.clear();
        tempBooksCollection.clear();
        tempTaskRoutes.clear();
        tempPath.clear();

    } while (std::prev_permutation(mask.begin(), mask.end()));
}

// DFS function to find schedules
void recursiveSearch(
    map<int, Assignment>& taskMap,
    map<string, int>& foodPricing,
    vector<int>& initialState,
    vector<int>& finalState,
    int& groupSize,
    vector<int> completedTasks,
    vector<int> booksCollection,
    vector<vector<pair<int, string>>> taskRoutes) {

    if (checkGoalAchieved(finalState, booksCollection)) {
        findCost(taskRoutes, foodPricing);
        // updatemin(taskRoutes);
        increaseCount();
        return;
    }

    auto executableTasks = getExecutableAssignments(taskMap, completedTasks, booksCollection);

    if (executableTasks.size() == 0) return;

    int taskCount = executableTasks.size();

    for (int i = groupSize; i <= groupSize; i++) {
        int r = i;
        vector<bool> mask(r, true);
        mask.resize(taskCount, false);

        makeCombinationsOfAssignmentsSelections(taskMap,
                                                foodPricing,
                                                initialState,
                                                finalState,
                                                groupSize,
                                                completedTasks,
                                                booksCollection,
                                                taskRoutes,
                                                mask,
                                                executableTasks);
    }
}

// Function to read input data
void get_input(map<int, Assignment>& taskMap, map<string, int>& foodPricing,
               vector<int>& initialState, vector<int>& finalState, int& groupSize) {

    string filename = inputFileName;
    ifstream inputFile(filename);
    if (!inputFile.is_open()) {
        cerr << "Error opening file!" << endl;
        return;
    }

    string line;
    while (getline(inputFile, line)) {
        if (line.empty() || line[0] == '%') {
            continue;
        }

        stringstream ss(line);
        string command;
        ss >> command;

        if (command == "C") {
            string foodLabel;
            int cost;
            ss >> foodLabel >> cost;
            foodPricing[foodLabel] = cost;
        } else if (command == "G") {
            ss >> groupSize;
        } else if (command == "I") {
            int book;
            while (ss >> book && book != -1) {
                initialState.push_back(book);
            }
        } else if (command == "O") {
            int outcome;
            while (ss >> outcome && outcome != -1) {
                finalState.push_back(outcome);
            }
        } else if (command == "A") {
            int id, input1, input2, output;
            string foodLabel;
            ss >> id >> input1 >> input2 >> output >> foodLabel;
            taskMap[id] = {{input1, input2}, output, foodLabel};
        }
    }

    inputFile.close();
}


int minCost= INT_MAX;
// Function to write paths to file
void findCost(const vector<vector<pair<int, string>>>& taskPath,  map<string, int>& foodPricing) {
   

    
    map<string, int> menuTracker;

    for (int i = 0; i < taskPath.size(); i++) {
        map<string, int> dailyMenu;
        for (int j = 0; j < taskPath[i].size(); j++) {
            dailyMenu[taskPath[i][j].second]++;
        }

        for (auto menu : dailyMenu) {
            auto foodLabel = menu.first;
            int count = menu.second;
            menuTracker[foodLabel] = max(menuTracker[foodLabel], count);
        }

        dailyMenu.clear();
    }

   int currcost=0;
    for (auto menu : menuTracker) {
         currcost+= menu.second *  foodPricing[menu.first] ;
    }
    menuTracker.clear();

    if(currcost<minCost){
        minCost= currcost;
        assignmtsRoute= taskPath;
    }

    
 }



void PrintSchedule(const vector<vector<pair<int, string>>>& taskPath) {
    
    for (int i = 0; i < taskPath.size(); i++) {
        cout<< "Day " << i + 1 << " : ";
        for (const auto& task : taskPath[i]) {
         cout << " assignment " << task.first << " ";
        }
        cout << "\n";
    }

    // cout << "Schedule Number " << totalSchedulesCount << " printed to file " << filename << endl;
}




int main() {

    map<string, int> foodPricing;
    vector<int> initialState;
    map<int, Assignment> taskMap;
    vector<int> finalState;

    int groupSize;

    get_input(taskMap, foodPricing, initialState, finalState, groupSize);

    int taskSize = taskMap.size();
    vector<int> completedTasks(taskSize + 1, 0);

    vector<vector<pair<int, string>>> taskRoutes;
    recursiveSearch(
        taskMap,
        foodPricing,
        initialState,
        finalState,
        groupSize,
        completedTasks, initialState, taskRoutes);

    // cout << "Total Sche/dule Found :  " << totalSchedulesCount;
    cout<<"The Minimum food cost is : "<<minCost<<" for schedule \n";
    PrintSchedule(assignmtsRoute);


    return 0;
}
