import os
import random

def generate_testcase(name, group_size=10, total_problems=15, max_time=50):
    group_size = random.randint(1, group_size) # random group size
    total_problems = random.randint(1, total_problems) # random number of problems
    with open(name, 'w') as r:
        r.write("% group size\n")
        r.write(f"G {group_size}\n")
        r.write("% Total number of problems\n")
        r.write(f"N {total_problems}\n")
        r.write("% problem-id time-required\n")
        problem_ids = list(range(1, total_problems + 1))
        
        for i in problem_ids:
            time_required = random.randint(1, max_time)
            r.write(f"P {i} {time_required}\n")

num_testcases = int(input("Enter the number of test cases to generate: "))
output_folder = "testcases"
os.makedirs(output_folder, exist_ok=True)

for i in range(1, num_testcases + 1):
    name = f"testcase_{i}.txt"
    name = os.path.join(output_folder, name)
    generate_testcase(name)

print(f"Generated {num_testcases} test cases in '{output_folder}' folder.")
