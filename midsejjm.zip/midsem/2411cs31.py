import sys
from z3 import *
def parse_group_size(line):
    tokens = line.split()
    if len(tokens) < 2:
        raise ValueError("Invalid input file -- group size")
    return int(tokens[1])

def parse_problem_count(line):
    tokens = line.split()
    if len(tokens) < 2:
        raise ValueError("Invalid input file -- number of problems")
    return int(tokens[1])

def parse_problem_data(lines):
    problems = []
    for line in lines:
        tokens = line.split()
        if len(tokens) < 3:
            continue  # Skip invalid lines
        p_id, tmp_time = int(tokens[1]), int(tokens[2])
        problems.append([p_id, tmp_time])
    
    problems.sort(key=lambda x: x[0])  # Maintain order of problems
    return problems

def get_input(input_location):
    try:
        with open(input_location, 'r') as il:
            inp = il.readlines()

        # Removing empty lines and comments
        inp_main = [x.strip() for x in inp if x.strip() and not x.startswith('%')]

        if len(inp_main) < 2:
            raise ValueError("Your Input file is invalid")

        # Dictionary to handle different input types
        handlers = {
            "G": parse_group_size,
            "N": parse_problem_count,
        }

        grpsize = handlers.get(inp_main[0][0], lambda _: None)(inp_main[0])
        prob_number = handlers.get(inp_main[1][0], lambda _: None)(inp_main[1])

        if grpsize is None or prob_number is None:
            raise ValueError("Invalid input file format")

        problems = parse_problem_data(inp_main[2:])

        # Extracting problem times
        problem_time = [time for _, time in problems]

        # Warn if the number of problems is inconsistent
        if len(problems) != prob_number:
            print("Warning: Number of problems in input file does not match the specified count. Using the first N problems.")
            prob_number = len(problems)

        return grpsize, prob_number, problem_time
    except Exception as e:
        print("Error in input file:", e)
        sys.exit(1)

    
def main(input_file):
    
    grpsize, problem_count, problems_time = get_input(input_file)
    print("Input proided:")
    print(" Group size:", grpsize)
    print("  Number of problems:", problem_count)
    print("  Task times:", problems_time)
    
    optimizer = Optimize()
    prob_number = len(problems_time)
    
# For each student, compute the total time of tasks assigned.
    timeTotal = [Int(f"timeTotal_{j}") for j in range(grpsize)]
    
    #mimize time to finish all problms
    # Set the objective: minimize time.

    time_req = Int("time")

    for i in range(grpsize):
        optimizer.add(time_req >= timeTotal[i])



    #student[i]=j means student i is assigned to task j
    student = [Int(f"student{i}") for i in range(prob_number)]

    for i in range(prob_number):
        optimizer.add(student[i] >= 0, student[i] < grpsize)
    
    

    #  if student is assisgned task j, then add the time of task to the total time of student
    for j in range(grpsize):
        optimizer.add(timeTotal[j] == Sum([If(student[i] == j, problems_time[i], 0) for i in range(prob_number)]))
    
    
    
    optimizer.minimize(time_req)
    
    if optimizer.check() == sat:
        print("\nThe problem is satidfiable.")
        z3_model = optimizer.model()
        min_t = z3_model.evaluate(time_req)

        if min_t is not None:
            print("\nMinimum time :", min_t.as_long())
            for j in range(grpsize):
                print(f"Student {j} worked for time :", z3_model.evaluate(timeTotal[j]))
            print("\nTask assignments:")
            for i in range(problem_count):
                student_id=  z3_model.evaluate(student[i])
                print(f" Problem number {i+1} completed by student: {student_id.as_long()+1} in time {problems_time[i]}")
        else:
                print("Infeasible.")
    else:
        print("No solution found.")
        return "Infeasible"


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python assg04.py inpit_file")
    else:
        input_file = sys.argv[1]
        main(input_file)
