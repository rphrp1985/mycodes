// $./a.exe testcases/input01.dag  use this to run the program

#include <iostream>
#include <fstream>
#include <bits/stdc++.h>
#include <string>
#include <utility>

using namespace std;

string inputFileName;
string outputFileName;
//Assignment class for storing assignment information;
class Assignment {
public:
    vector<int> inputRequirements; // Requirements to complete the assignment
    int outputAssignment;               // Output after completing the assignment
    string foodLabel;                    // food required to complete the assignment    

};


void get_input(map<int, Assignment>& taskMap, map<string, int>& foodPricing,
               vector<int>& initialState, vector<int>& finalState, int& groupSize) {

    string filename = inputFileName;
    ifstream inputFile(filename);
    if (!inputFile.is_open()) {
        cerr << "Error opening file!" << endl;
        exit(1);
        return;
    }

    string line;
    while (getline(inputFile, line)) {
        if (line.empty() || line[0] == '%') {
            continue;
        }

        stringstream ss(line);
        string command;
        ss >> command;

        
        int commandType = -1;
        if (command == "C") commandType = 0;
        else if (command == "G") commandType = 1;
        else if (command == "I") commandType = 2;
        else if (command == "O") commandType = 3;
        else if (command == "A") commandType = 4;

        switch (commandType) {
            case 0: { // "C" for food pricing
                string foodLabel;
                int cost;
                ss >> foodLabel >> cost;
                foodPricing[foodLabel] = cost;
                break;
            }
            case 1: { // "G" for group size
                ss >> groupSize;
                break;
            }
            case 2: { // "I" for initial state
                int book;
                while (ss >> book && book != -1) {
                    initialState.push_back(book);
                }
                break;
            }
            case 3: { // "O" for final state
                int outcome;
                while (ss >> outcome && outcome != -1) {
                    finalState.push_back(outcome);
                }
                break;
            }
            case 4: { // "A" for task map
                int id, input1, input2, output;
                string foodLabel;
                ss >> id >> input1 >> input2 >> output >> foodLabel;
                taskMap[id] = {{input1, input2}, output, foodLabel};
                break;
            }
            default:
                cerr << "Unknown command: " << command << endl;
                break;
        }
    }

    inputFile.close();
}

int heuristic_q1(int g, int assignmentsRemaining, int groupSize) {
    //g = number of days taken to reach this state 
    //h = number of days required to reach goal state   assignment remaining/ group size
    int h = (assignmentsRemaining+ groupSize-1 )/ groupSize;  // taking ceil value
    return g+h+1; // 1= this day
}

int get_daily_max_food_cost(vector<vector<pair<int, string>>> taskRoutes_till_state, map<string, int>& foodPricing) {
    int g=0;
    for(auto day : taskRoutes_till_state){
        
    int currmax=0;
    for (int j = 0; j < day.size(); j++) {
        int cost = foodPricing[day[j].second];
        currmax+=cost;
    }
    g= max(g,currmax);  
    
  }

  return g;

}


int heuristic_q2(int g,  vector<vector<pair<int, string>>> taskRoutes_till_state, map<string, int>& foodPricing, map<int, Assignment> taskMap, vector<int> completedTask, int grpsize) {
   int h=0;  // max possible daily food cost
  for(auto day : taskRoutes_till_state){

    int currmax=0;
    for (int j = 0; j < day.size(); j++) {
        int cost = foodPricing[day[j].second];
        currmax+=cost;
    }
    g= max(g,currmax);  
    
  }

    vector<int> v; // tkaing max x remaing food cost so that we can get minimum cost.
    for(auto task:taskMap){

        if(completedTask[task.first]==0){
            int cost = foodPricing[task.second.foodLabel];
          v.push_back(cost);
        }




    }

    sort(v.begin(),v.end(),greater<int>());

    for(int i=0;i<grpsize && i<v.size();i++){
        h+=v[i];
    }
  

    return g+h;
  }




struct SubState {
    int fn;
    int g;
    vector<int> completedTasks;  // Stores IDs of completed tasks
    vector<int> booksCollection; // Stores collected books
    vector<vector<pair<int, string>>> taskRoutes; // Stores tassignment completion path
};

bool checkGoalAchieved(
    vector<int>& finalState,
    vector<int> booksCollection) {

    int goalAchieved = 1; // Assume goal is achieved initially

for (int i = 0; i < finalState.size(); i++) {
    int goalItem = finalState[i];
    int itemFound = 0; // Assume goal item is not found
    
    for (int j = 0; j < booksCollection.size(); j++) {
        int book = booksCollection[j];
        if (book == goalItem) {
            itemFound = 1; // Goal item is found
        }
    }
    
    if (itemFound == 0) {
        goalAchieved = 0; // Goal item not found
    }
}

return goalAchieved;
}

//writing to file
void writePathToFile(const vector<vector<vector<pair<int, string>>>>& allsol) {

    string filename = outputFileName;
    fstream outputFile(filename, ios::out);
    for(auto taskPath:allsol){
  

    if (!outputFile) {
        cerr << "Error: Unable to open file \"" << filename << "\" for writing." << endl;
        return;
    }

    for (int i = 0; i < taskPath.size(); i++) {
        outputFile << "Day " << i + 1 << " : ";
        for (const auto& task : taskPath[i]) {
            outputFile << " assignment " << task.first << " ";
        }
        outputFile << "\n";
    }

    map<string, int> menuTracker;

    for (int i = 0; i < taskPath.size(); i++) {
        map<string, int> dailyMenu;
        for (int j = 0; j < taskPath[i].size(); j++) {
            dailyMenu[taskPath[i][j].second]++;
        }

        for (auto menu : dailyMenu) {
            auto foodLabel = menu.first;
            int count = menu.second;
            menuTracker[foodLabel] = max(menuTracker[foodLabel], count);
        }

        dailyMenu.clear();
    }

    outputFile << "Food Menu : [ ";
    for (auto menu : menuTracker) {
        outputFile << menu.second << " - " << menu.first << " , ";
    }
    menuTracker.clear();
    outputFile << " ] ";

    outputFile << "\n\n\n";
   

    // cout << "Schedule Number " << totalSchedulesCount << " printed to file " << filename << endl;
}
 outputFile.close();
}


vector<pair<int, pair<int, string>>> getExecutableAssignments(
    map<int, Assignment>& taskMap,
    vector<int> completedTasks,
    vector<int> booksCollection) {

   vector<pair<int, pair<int, string>>> executableTasks;

for (int i = 1; i <= taskMap.size(); i++) {
    // Check if the task is not completed
    if (completedTasks[i] == 0) {
        int isValid = 1; // Assume the task is valid initially

        // Check input requirements for the task
        for (int j = 0; j < taskMap[i].inputRequirements.size(); j++) {
            int requirement = taskMap[i].inputRequirements[j];
            int isAvailable = 0; // Assume the requirement is not available

            // Search for the requirement in the booksCollection
            for (int k = 0; k < booksCollection.size(); k++) {
                int book = booksCollection[k];
                if (book == requirement) {
                    isAvailable = 1; // Requirement found
                }
            }

            // If the requirement is not available, the task is invalid
            if (isAvailable == 0) {
                isValid = 0;
            }
        }

        // If the task is valid, add it to the executableTasks
        if (isValid == 1) {
            int taskOutput = taskMap[i].outputAssignment;
            string taskLabel = taskMap[i].foodLabel;
            executableTasks.push_back({i, {taskOutput, taskLabel}});
        }
    }
}

    return executableTasks;
}

vector<SubState> makeCombinationsOfAssignmentsSelections(
    map<int, Assignment>& taskMap,
    map<string, int>& foodPricing,
    vector<int>& initialState,
    vector<int>& finalState,
    int& groupSize,
    vector<int> completedTasks,
    vector<int> booksCollection,
    vector<vector<pair<int, string>>> taskRoutes,
    vector<bool> mask,
    vector<pair<int, pair<int, string>>> executableTasks,
    int grpSize,
    int g
    ) {

    int taskCount = executableTasks.size();

    vector<SubState> v;

    do {
    // Temporary variables to hold current states
    vector<int> tempCompletedTasks = completedTasks; // Copying the completed tasks
    vector<int> tempBooksCollection = booksCollection; // Copying the books collection
    vector<vector<pair<int, string>>> tempTaskRoutes = taskRoutes; // Copying the task routes

    // Create a combination vector to store selected tasks
    vector<pair<int, pair<int, string>>> combination;
    for (int i = 0; i < taskCount; ++i) {
        if (mask[i]) { // Check if the mask allows this task
            combination.push_back(executableTasks[i]); // Add task to combination
        }
    }

    // A temporary path vector to store the current route
    vector<pair<int, string>> tempPath;
    for (auto task : combination) {
        // Get the output assignment of the current task
        int taskOutput = taskMap[task.first].outputAssignment;

        // Add the task's first element and its food label to the path
        tempPath.push_back({task.first, taskMap[task.first].foodLabel});
        tempBooksCollection.push_back(taskOutput); // Add the output to books collection
        tempCompletedTasks[task.first] = 1; // Mark the task as completed
    }

    // Push the path into the task routes
    tempTaskRoutes.push_back(tempPath);


    int fn = heuristic_q1(g, executableTasks.size(), grpSize);
    // Create a substate to store the modified data
    struct SubState substate = {
        fn,
        g+1, // Increment the day
        tempCompletedTasks, // Update the completed tasks
        tempBooksCollection, // Update the books collection
        tempTaskRoutes // Update the task routes
    };

    // Add the current substate to the vector
    v.push_back(substate);

    // free up memory
    tempCompletedTasks.clear();
    tempBooksCollection.clear();
    tempTaskRoutes.clear();
    tempPath.clear(); // Emptying the path for the next iteration

    
    int n = mask.size();
    int k = n - 1;

    
    while (k > 0 && mask[k - 1] <= mask[k]) {
        --k;
    }

    if (k > 0) {
        int l = n - 1;

        // Find the largest element to the right of `k - 1` that is smaller than mask[k - 1]
        while (mask[l] >= mask[k - 1]) {
            --l;
        }

        // Swap the two elements
        swap(mask[k - 1], mask[l]);
    }

    // Reverse the sequence from `k` to the end of the array
    reverse(mask.begin() + k, mask.end());

} while (!is_sorted(mask.begin(), mask.end(), greater<int>())); // Continue until the mask is sorted in descending order

    return v;
}


vector<SubState> makeCombinationsOfAssignmentsSelections_q2(
    map<int, Assignment>& taskMap,
    map<string, int>& foodPricing,
    vector<int>& initialState,
    vector<int>& finalState,
    int& groupSize,
    vector<int> completedTasks,
    vector<int> booksCollection,
    vector<vector<pair<int, string>>> taskRoutes,
    vector<bool> mask,
    vector<pair<int, pair<int, string>>> executableTasks,
    int grpSize,
    int g
    ) {

    int taskCount = executableTasks.size();

    vector<SubState> v;

    do {
    // Temporary variables to hold current states
    vector<int> tempCompletedTasks = completedTasks; // Copying the completed tasks
    vector<int> tempBooksCollection = booksCollection; // Copying the books collection
    vector<vector<pair<int, string>>> tempTaskRoutes = taskRoutes; // Copying the task routes

    // Create a combination vector to store selected tasks
    vector<pair<int, pair<int, string>>> combination;
    for (int i = 0; i < taskCount; ++i) {
        if (mask[i]) { // Check if the mask allows this task
            combination.push_back(executableTasks[i]); // Add task to combination
        }
    }

    // A temporary path vector to store the current route
    vector<pair<int, string>> tempPath;
    for (auto task : combination) {
        // Get the output assignment of the current task
        int taskOutput = taskMap[task.first].outputAssignment;

        // Add the task's first element and its food label to the path
        tempPath.push_back({task.first, taskMap[task.first].foodLabel});
        tempBooksCollection.push_back(taskOutput); // Add the output to books collection
        tempCompletedTasks[task.first] = 1; // Mark the task as completed
    }

    // Push the path into the task routes
    tempTaskRoutes.push_back(tempPath);


    int fn = heuristic_q2(g,tempTaskRoutes,foodPricing,taskMap,tempCompletedTasks,grpSize);
    int g_temp= get_daily_max_food_cost(tempTaskRoutes,foodPricing);
    // Create a substate to store the modified data
    struct SubState substate = {
        fn,
        g_temp, 
        tempCompletedTasks, // Update the completed tasks
        tempBooksCollection, // Update the books collection
        tempTaskRoutes // Update the task routes
    };

    // Add the current substate to the vector
    v.push_back(substate);

    // free up memory
    tempCompletedTasks.clear();
    tempBooksCollection.clear();
    tempTaskRoutes.clear();
    tempPath.clear(); // Emptying the path for the next iteration

    
    int n = mask.size();
    int k = n - 1;

    
    while (k > 0 && mask[k - 1] <= mask[k]) {
        --k;
    }

    if (k > 0) {
        int l = n - 1;

        // Find the largest element to the right of `k - 1` that is smaller than mask[k - 1]
        while (mask[l] >= mask[k - 1]) {
            --l;
        }

        // Swap the two elements
        swap(mask[k - 1], mask[l]);
    }

    // Reverse the sequence from `k` to the end of the array
    reverse(mask.begin() + k, mask.end());

} while (!is_sorted(mask.begin(), mask.end(), greater<int>())); // Continue until the mask is sorted in descending order

    return v;
}



//printing the schedule to console
void PrintSchedule(const vector<vector<pair<int, string>>>& taskPath) {
    
    for (int i = 0; i < taskPath.size(); i++) {
        cout<< "Day " << i + 1 << " :";
        for (const auto& task : taskPath[i]) {
         cout << " A" << task.first ;;
         if(task!=taskPath[i].back())
            cout<<",";

        }
        cout << "\n";
    }

    // cout << "Schedule Number " << totalSchedulesCount << " printed to file " << filename << endl;
}


bool verify_menu(vector<vector<pair<int, string>>> taskPath,map<string, int> givenMenu ){

    map<string, int> menuTracker;

    for (int i = 0; i < taskPath.size(); i++) {
        map<string, int> dailyMenu;
        for (int j = 0; j < taskPath[i].size(); j++) {
            dailyMenu[taskPath[i][j].second]++;
        }

        for (auto menu : dailyMenu) {
            auto foodLabel = menu.first;
            int count = menu.second;
            menuTracker[foodLabel] = max(menuTracker[foodLabel], count);
        }

        dailyMenu.clear();
    }

   

    if(menuTracker!=givenMenu){
        return false;
    }
    return true;

}


bool discard_path_for_unwanted_menu(vector<vector<pair<int, string>>> &taskPath,map<string, int> givenMenu ){

    return true;
    map<string, int> menuTracker;

    for (int i = 0; i < taskPath.size(); i++) {
        map<string, int> dailyMenu;
        for (int j = 0; j < taskPath[i].size(); j++) {
            dailyMenu[taskPath[i][j].second]++;
        }

        for (auto menu : dailyMenu) {
            auto foodLabel = menu.first;
            int count = menu.second;
            menuTracker[foodLabel] = max(menuTracker[foodLabel], count);
        }

        dailyMenu.clear();
    }

    
    auto temp_given_menu = givenMenu;
    for(auto it:menuTracker){
        if(temp_given_menu[it.first]<it.second){
            return false;
        }
    }

    


    return true;

}

int q1_dfbb_visted_node=0;
int q1_dfbb_min_h=INT_MAX;
vector<vector<pair<int, string>>> q1_dfbb_solution;
void recursiveSearch_q1_dfbb(
    map<int, Assignment>& taskMap,
    map<string, int>& foodPricing,
    vector<int>& initialState,
    vector<int>& finalState,
    int& groupSize,
    vector<int> completedTasks,
    vector<int> booksCollection,
    vector<vector<pair<int, string>>> taskRoutes,
    map<string, int>& givenMenu,
    int grpSize,
    int g ) {

    q1_dfbb_visted_node++;
    if (checkGoalAchieved(finalState, booksCollection)) {
        if(verify_menu(taskRoutes,givenMenu)){
        if(g<q1_dfbb_min_h){
            q1_dfbb_min_h=g;
            q1_dfbb_solution=taskRoutes;
            // PrintSchedule(taskRoutes);
        }
    }
        return;

    }

    auto executableTasks = getExecutableAssignments(taskMap, completedTasks, booksCollection);

    if (executableTasks.size() == 0) return;

    int taskCount = executableTasks.size();

    for (int i = groupSize; i <= groupSize; i++) {
        int r = i;
        vector<bool> mask(r, true);
        mask.resize(taskCount, false);

        auto it = makeCombinationsOfAssignmentsSelections(taskMap,
                                                foodPricing,
                                                initialState,
                                                finalState,
                                                groupSize,
                                                completedTasks,
                                                booksCollection,
                                                taskRoutes,
                                                mask,
                                                executableTasks,
                                                groupSize,
                                                g
                                                );
        
        for(auto i:it){
            
            if(i.fn<q1_dfbb_min_h && discard_path_for_unwanted_menu(i.taskRoutes,givenMenu)){
                recursiveSearch_q1_dfbb(
                taskMap,
                foodPricing,
                initialState,
                finalState,
                groupSize,
                i.completedTasks,
                i.booksCollection,
                i.taskRoutes,
                givenMenu,
                groupSize,
                i.g
                );
            }
            


        }


    }
}





int q2_dfbb_visted_node=0;
int q2_dfbb_min_h=INT_MAX;
vector<vector<pair<int, string>>> q2_dfbb_solution;
void recursiveSearch_q2_dfbb(
    map<int, Assignment>& taskMap,
    map<string, int>& foodPricing,
    vector<int>& initialState,
    vector<int>& finalState,
    int& groupSize,
    vector<int> completedTasks,
    vector<int> booksCollection,
    vector<vector<pair<int, string>>> taskRoutes,
    map<string, int>& givenMenu,
    int grpSize,
    int g,
    int k ) {

    q2_dfbb_visted_node++;
    if (checkGoalAchieved(finalState, booksCollection)) {
        if(taskRoutes.size()<=k){
            if(get_daily_max_food_cost(taskRoutes,foodPricing)<q2_dfbb_min_h){
                q2_dfbb_min_h=get_daily_max_food_cost(taskRoutes,foodPricing);
                q2_dfbb_solution=taskRoutes;
            }

        }
        
        return;
    }

    auto executableTasks = getExecutableAssignments(taskMap, completedTasks, booksCollection);

    if (executableTasks.size() == 0) return;

    int taskCount = executableTasks.size();

    for (int i = groupSize; i <= groupSize; i++) {
        int r = i;
        vector<bool> mask(r, true);
        mask.resize(taskCount, false);

        auto it = makeCombinationsOfAssignmentsSelections_q2(taskMap,
                                                foodPricing,
                                                initialState,
                                                finalState,
                                                groupSize,
                                                completedTasks,
                                                booksCollection,
                                                taskRoutes,
                                                mask,
                                                executableTasks,
                                                groupSize,
                                                g
                                                );
        
        for(auto i:it){
            
            if(i.fn<q2_dfbb_min_h && i.taskRoutes.size()<=k ){
                recursiveSearch_q2_dfbb(
                taskMap,
                foodPricing,
                initialState,
                finalState,
                groupSize,
                i.completedTasks,
                i.booksCollection,
                i.taskRoutes,
                givenMenu,
                groupSize,
                i.g,
                k
                );
            }
            


        }


    }
}





int q1_dfs_visted_node=0;
vector<vector<pair<int, string>>> q1_dfs_solution;
void recursiveSearch_q1_dfs(
    map<int, Assignment>& taskMap,
    map<string, int>& foodPricing,
    vector<int>& initialState,
    vector<int>& finalState,
    int& groupSize,
    vector<int> completedTasks,
    vector<int> booksCollection,
    vector<vector<pair<int, string>>> taskRoutes,
    map<string, int>& givenMenu,
    int grpSize,
    int g ) {

    q1_dfs_visted_node++;
    if (checkGoalAchieved(finalState, booksCollection)) {
        // cout<<"dfs sol \n";

        if(q1_dfs_solution.size()>taskRoutes.size()|| q1_dfs_solution.size()==0){

            // PrintSchedule(taskRoutes);
            if(verify_menu(taskRoutes,givenMenu)){
            q1_dfs_solution=taskRoutes;
            }
        }

        return;
    }

    auto executableTasks = getExecutableAssignments(taskMap, completedTasks, booksCollection);

    if (executableTasks.size() == 0) return;

    int taskCount = executableTasks.size();

    for (int i = groupSize; i <= groupSize; i++) {
        int r = i;
        vector<bool> mask(r, true);
        mask.resize(taskCount, false);

        auto it = makeCombinationsOfAssignmentsSelections(taskMap,
                                                foodPricing,
                                                initialState,
                                                finalState,
                                                groupSize,
                                                completedTasks,
                                                booksCollection,
                                                taskRoutes,
                                                mask,
                                                executableTasks,
                                                groupSize,
                                                g
                                                );
        
        for(auto i:it){
            
            if( discard_path_for_unwanted_menu(i.taskRoutes,givenMenu)){
                recursiveSearch_q1_dfs(
                taskMap,
                foodPricing,
                initialState,
                finalState,
                groupSize,
                i.completedTasks,
                i.booksCollection,
                i.taskRoutes,
                givenMenu,
                groupSize,
                i.g
                );
            }
            


        }


    }
}




int q2_dfs_visted_node=0;
int q2_dfs_min_h=INT_MAX;
vector<vector<pair<int, string>>> q2_dfs_solution;
void recursiveSearch_q2_dfs(
    map<int, Assignment>& taskMap,
    map<string, int>& foodPricing,
    vector<int>& initialState,
    vector<int>& finalState,
    int& groupSize,
    vector<int> completedTasks,
    vector<int> booksCollection,
    vector<vector<pair<int, string>>> taskRoutes,
    map<string, int>& givenMenu,
    int grpSize,
    int g ,
    int k) {

    q2_dfs_visted_node++;
    if (checkGoalAchieved(finalState, booksCollection)) {
        
        if(taskRoutes.size()<=k){
          q2_dfs_min_h= min(get_daily_max_food_cost(taskRoutes,foodPricing),q2_dfs_min_h);
        q2_dfs_solution=taskRoutes;
        }


        
    }

    auto executableTasks = getExecutableAssignments(taskMap, completedTasks, booksCollection);

    if (executableTasks.size() == 0) return;

    int taskCount = executableTasks.size();

    for (int i = groupSize; i <= groupSize; i++) {
        int r = i;
        vector<bool> mask(r, true);
        mask.resize(taskCount, false);

        auto it = makeCombinationsOfAssignmentsSelections_q2(taskMap,
                                                foodPricing,
                                                initialState,
                                                finalState,
                                                groupSize,
                                                completedTasks,
                                                booksCollection,
                                                taskRoutes,
                                                mask,
                                                executableTasks,
                                                groupSize,
                                                g
                                                );
        
        for(auto i:it){
            
            
                recursiveSearch_q2_dfs(
                taskMap,
                foodPricing,
                initialState,
                finalState,
                groupSize,
                i.completedTasks,
                i.booksCollection,
                i.taskRoutes,
                givenMenu,
                groupSize,
                i.g,
                k
                );
            
            


        }


    }
}





int main(int argc, char* argv[]) {

       if (argc < 2) {
        cerr << "Usage: " << argv[0] << " <input_file>" << endl;
        return 1;
    }

    inputFileName = argv[1];
    // inputFileName= "testcases/input01.dag";
    outputFileName="out.dag";
    cout<<"Opening File "<<inputFileName<<endl;
    map<string, int> foodPricing;
    vector<int> initialState;
    map<int, Assignment> taskMap;
    vector<int> finalState;

    int groupSize;

    // getting input from file
    get_input(taskMap, foodPricing, initialState, finalState, groupSize);

    int taskSize = taskMap.size();
    vector<int> completedTasks1(taskSize + 1, 0);

    vector<vector<pair<int, string>>> taskRoutes1;

    // taking inputs from user.
    int k ;
    cout<<"Enter the value of k\n";
    cin>>k;

    map<string,int> givenMenu;
    cout<<"enter the menu. To finish entering the menu enter -1.\nFormat dish-name count\n";


    while(true){
        string x;
        int y;
        cin>>x;
        if(x=="-1"){
            break;
        }
        cin>>y;
        givenMenu[x]=y;
    }

    // applying BFS
    struct CompareSubState {
        bool operator()(const SubState& a, const SubState& b) {
            return a.fn < b.fn; // Min-heap based on fn value
        }
    };

    struct CompareSubState2 {
        bool operator()(const SubState& a, const SubState& b) {
            return a.fn > b.fn; // Min-heap based on fn value
        }
    };

    priority_queue<SubState, vector<SubState>, CompareSubState> q;    
    int f = heuristic_q1(0, taskSize, groupSize);
    struct SubState task = {
        f,  // fn value.
        0,  // g value.  
    completedTasks1,                        
    initialState,                          
    taskRoutes1            
   };

    q.push(task);
    

    vector<vector<pair<int, string>>> a_start_solution; ;
    int count=0;
    int a_star_q1_visted_node=0;
    while(!q.empty()){

        auto it = q.top();
        q.pop();
       a_star_q1_visted_node++;
        // cout<<"selected with h= "<<it.fn<<" and g= "<<it.g<<endl;
      
        auto booksCollection= it.booksCollection;
        vector<int> completedTasks = it.completedTasks;
        vector<vector<pair<int, string>>> taskRoutes= it.taskRoutes;

        if (checkGoalAchieved(finalState, booksCollection)) { // this path reaches goal state.
          

    //         map<string, int> menuTracker;

    // for(auto it: taskRoutes){
    //     for(auto it2:it){
    //         menuTracker[it2.second]++;
    //     }
    // }

    //         for(auto it: menuTracker){
    //             cout<<it.first<<" "<<it.second<<"\n";
    //         }
    //         cout<<"\n\n\n\n";
        //   cout<<"Visted Nodes : "<<a_star_q1_visted_node<<endl;
            writePathToFile({taskRoutes});
        if(verify_menu(taskRoutes,givenMenu)){
            // cout<<"execired\n";
           a_start_solution= taskRoutes;
        
           break;
        }
     continue;
        
    }

    auto executableTasks = getExecutableAssignments(taskMap, completedTasks, booksCollection);


    if (executableTasks.size() == 0) continue;;
    
        int taskCount = executableTasks.size();
        vector<bool> mask(groupSize, true);
        mask.resize(taskCount, false);

        // getting combinations of executable tasks.
        auto combinations= makeCombinationsOfAssignmentsSelections(taskMap,
                                                foodPricing,
                                                initialState,
                                                finalState,
                                                groupSize,
                                                completedTasks,
                                                booksCollection,
                                                taskRoutes,
                                                mask,
                                                executableTasks,
                                                groupSize,
                                                it.g
                                                );

        for(auto it:combinations){  // adding next state to queue/
        // if(discard_path_for_unwanted_menu(it.taskRoutes,givenMenu)){
            q.push(it);
        // }

    }}

    
    completedTasks1.resize(taskSize + 1, 0);
    taskRoutes1.clear();

    recursiveSearch_q1_dfbb(
        taskMap,
        foodPricing,
        initialState,
        finalState,
        groupSize,
        completedTasks1, initialState, taskRoutes1,
        givenMenu,
        groupSize,
        0
        );

    completedTasks1.resize(taskSize + 1, 0);
    taskRoutes1.clear();

        recursiveSearch_q1_dfs(
        taskMap,
        foodPricing,
        initialState,
        finalState,
        groupSize,
        completedTasks1, initialState, taskRoutes1,
        givenMenu,
        groupSize,
        0
        );


//////////////////////////////    2nd question ///////////////////////////////////////////////
    completedTasks1.resize(taskSize + 1, 0);
    taskRoutes1.clear();


    priority_queue<SubState, vector<SubState>, CompareSubState2> q2;    
    f = heuristic_q2(0, taskRoutes1, foodPricing,taskMap,completedTasks1,groupSize); 
    struct SubState task_q2 = {
        f,  // fn value.
        0,  // g value.  
    completedTasks1,                        
    initialState,                          
    taskRoutes1            
   };

    q2.push(task_q2);
    

    vector<vector<pair<int, string>>> a_start_solution_q2; ;
    count=0;
    int q2_min_daily_food_cost=INT_MAX;
    int a_star_q2_visted_node=0;

    while(!q2.empty()){

        auto it = q2.top();
        q2.pop();
       a_star_q2_visted_node++;
    //    cout<<a_star_q2_visted_node<<"\n ";

    //    if(a_star_q2_visted_node>5000)
    //    break;
        // cout<<"selected with h= "<<it.fn<<" and g= "<<it.g<<endl;
      
        auto booksCollection= it.booksCollection;
        vector<int> completedTasks = it.completedTasks;
        vector<vector<pair<int, string>>> taskRoutes= it.taskRoutes;

        if (checkGoalAchieved(finalState, booksCollection)) { // this path reaches goal state.
          
          if( taskRoutes.size()<=k){
            a_start_solution_q2= taskRoutes;
            q2_min_daily_food_cost= min(get_daily_max_food_cost(taskRoutes,foodPricing),q2_min_daily_food_cost);
            break;
          }

     continue;
        
    }

    auto executableTasks = getExecutableAssignments(taskMap, completedTasks, booksCollection);


    if (executableTasks.size() == 0) continue;;
    
        int taskCount = executableTasks.size();
        vector<bool> mask(groupSize, true);
        mask.resize(taskCount, false);

        // getting combinations of executable tasks.
        auto combinations= makeCombinationsOfAssignmentsSelections_q2(taskMap,
                                                foodPricing,
                                                initialState,
                                                finalState,
                                                groupSize,
                                                completedTasks,
                                                booksCollection,
                                                taskRoutes,
                                                mask,
                                                executableTasks,
                                                groupSize,
                                                it.g
                                                );

        for(auto it:combinations){  // adding next state to queue/
       
            if(it.taskRoutes.size()<=k){
            q2.push(it);
            
            }
        

    }}



 
    completedTasks1.resize(taskSize + 1, 0);
    taskRoutes1.clear();

    recursiveSearch_q2_dfbb(
        taskMap,
        foodPricing,
        initialState,
        finalState,
        groupSize,
        completedTasks1, initialState, taskRoutes1,
        givenMenu,
        groupSize,
        0,
        k
        );



     completedTasks1.resize(taskSize + 1, 0);
    taskRoutes1.clear();

        recursiveSearch_q2_dfs(
        taskMap,
        foodPricing,
        initialState,
        finalState,
        groupSize,
        completedTasks1, initialState, taskRoutes1,
        givenMenu,
        groupSize,
        0,k
        );




// ?/////////////////////////       SOLUTION printing //////////////////////////////
  
   cout<<"**********************    Question 1 - A* Algorithm     **************************\n";
   cout<<"Visted Nodes : "<<a_star_q1_visted_node<<endl;
   if(a_start_solution.size()==0){
       cout<<"No solution found\n";
   }else{
        
        PrintSchedule(a_start_solution);
   }

     cout<<"\n\n**********************    Question 1 - DFBB Algorithm     **************************\n";
   cout<<"Visted Nodes : "<<q1_dfbb_visted_node<<endl;
   if(q1_dfbb_solution.size()==0){
       cout<<"No solution found\n";
   }else{
        
        PrintSchedule(q1_dfbb_solution);
   }


  cout<<"\n\n**********************    Question 1 - DFS Algorithm     **************************\n";
   cout<<"Visted Nodes : "<<q1_dfs_visted_node<<endl;
   
   if(q1_dfs_solution.size()==0){
       cout<<"No solution found\n";
   }else{
        
        PrintSchedule(q1_dfs_solution);
   }

 cout<<"**********************    Question 2 - A* Algorithm     **************************\n";
   cout<<"Visted Nodes : "<<a_star_q2_visted_node<<endl;
   cout<<"minimum daily food cost is "<<q2_min_daily_food_cost<<endl;
   if(a_start_solution_q2.size()==0){
       cout<<"No solution found\n";
   }else{
        
        PrintSchedule(a_start_solution_q2);
   }


    cout<<"**********************    Question 2 - DFBB Algorithm     **************************\n";
   cout<<"Visted Nodes : "<<q2_dfbb_visted_node<<endl;
   cout<<"minimum daily food cost is "<<q2_dfbb_min_h<<endl;
   if(q2_dfbb_solution.size()==0){
       cout<<"No solution found\n";
   }else{
        
        PrintSchedule(q2_dfbb_solution);
   }


   cout<<"**********************    Question 2 - DFS Algorithm     **************************\n";
   cout<<"Visted Nodes : "<<q2_dfs_visted_node<<endl;
   cout<<"minimum daily food cost is "<<q2_dfs_min_h<<endl;
   if(q2_dfs_solution.size()==0){
       cout<<"No solution found\n";
   }else{
        
        PrintSchedule(q2_dfs_solution);
   }


    

   
    return 0;
}

